#!/bin/sh

# it is assumed that a Java 8 or newer JRA is on the PATH

java -jar st80vm.jar --statusline --tz:60 --stats 1186-dv6/Smalltalk/snapshot
