#!/bin/sh

# it is assumed that a Java 8 or newer JRA is on the PATH

java -cp ../st80vm.jar dev.hawala.st80vm.alto.AltoFile $*
